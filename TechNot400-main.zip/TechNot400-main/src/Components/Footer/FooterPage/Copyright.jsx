import React from 'react'

const Copyright = () => {
  return (
    <div className='overflow-x-hidden overflow-y-hidden py-6 text-sm text-center text-gray-500 dark:text-gray-600'>
        © TRUBLE. All rights reserved.
    </div>
  )
}

export default Copyright